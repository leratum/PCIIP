<?php 

$ник = filter_var(trim($_POST['nik']), FILTER_SANITIZE_STRING); // Удаляет все лишнее и записываем значение в переменную //$login
$логин = filter_var(trim($_POST['login']), FILTER_SANITIZE_STRING);
$пароль = filter_var(trim($_POST['pass']), FILTER_SANITIZE_STRING);

if(mb_strlen($ник) < 3 || mb_strlen($ник)> 50) {
    echo "Недопустимая длинна ника";
    exit();
}

else if (mb_strlen($логин) < 5 || mb_strlen($логин) > 90)
{
    echo "Недопустимая длинна логина"; 
    exit();
}

else if(mb_strlen($пароль) < 5) {
    echo "Недопустимая длинна пароля (менее 6 символов)";
    exit();
}

$пароль = md5($пароль."jkvdfy7e34");

$mysql = new mysqli('localhost', 'lera', 'attack', 'oasis');
$mysql->query("INSERT INTO `users` (`Ник`, `Логин`, `Пароль`)
VALUES('$ник', '$логин', '$пароль')");
$mysql->close();

header('Location: /');

 ?>