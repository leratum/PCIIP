<?php

$логин = filter_var(trim($_POST['login']), FILTER_SANITIZE_STRING);
$пароль = filter_var(trim($_POST['pass']), FILTER_SANITIZE_STRING);

$пароль = md5($пароль."jkvdfy7e34");

$mysql = new mysqli('localhost', 'lera', 'attack', 'oasis');

$result = $mysql->query("SELECT * FROM `users` WHERE `login` = 
'$логин' AND `pass` = '$пароль'");

$user = "сохранено";
if(count($user) == 0){
	echo "Такой пользователь не найден";
	exit();
}

setcookie('user', $user['Ник'], time() + 3600, "/");

$mysql->close();

header('Location: /');

?>