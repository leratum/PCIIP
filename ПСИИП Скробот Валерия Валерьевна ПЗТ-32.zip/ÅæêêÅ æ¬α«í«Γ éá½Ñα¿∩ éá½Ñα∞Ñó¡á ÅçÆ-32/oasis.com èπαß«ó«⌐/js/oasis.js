setTimeout(function(){
    document.body.classList.add('body_visible');
}, 200);

document.getElementById('submit_bottom').onclick = function() {
        setTimeout(function() {
            document.getElementById('js_submit').innerHTML = 'Спасибо за помощь с сайтом!';
        }, 500);
};