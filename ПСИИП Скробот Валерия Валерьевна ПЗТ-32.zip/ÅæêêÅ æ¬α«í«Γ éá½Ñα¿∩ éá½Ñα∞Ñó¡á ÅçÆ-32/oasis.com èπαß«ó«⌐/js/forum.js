setTimeout(function(){
    document.body.classList.add('body_visible');
}, 200);

const button1 = document.querySelector('#subscription_1')
const button2 = document.querySelector('#subscription_2')
const button3 = document.querySelector('#subscription_3')

button2.addEventListener('click', () => {
    if(button2.classList.contains("active")) {
        button2.classList.remove('active')
        button2.innerHTML = "Подписаться"
    } else {
        button2.classList.add('active');
        button2.innerHTML = "Отписаться"
    }

})
button1.addEventListener('click', () => {
    if(button1.classList.contains("active")) {
        button1.classList.remove('active')
        button1.innerHTML = "Подписаться"
    } else {
        button1.classList.add('active');
        button1.innerHTML = "Отписаться"
    }

})
button1.addEventListener('click', () => {
    if(button1.classList.contains("active")) {
        button1.classList.remove('active')
        button1.innerHTML = "Подписаться"
    } else {
        button1.classList.add('active');
        button1.innerHTML = "Отписаться"
    }

})


