<?php
require_once 'podkl/database.php';
require_once 'podkl/functions.php';
?>

<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="UTF-8">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;500;600;700;800&family=Oswald:wght@200;300;400;500;600;700&family=Playfair+Display:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <meta name="viewport"
        content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="/css/1.css">
  <link rel="icon" href="icon/Oasis.png">
  <title>forum</title>
</head>
<body>
<!--Шапка профиля-->
<header class="header" id="back">
    <div class="container">
        <div class="header_menu">
            <a href="oasis.html" class="menu menu_oasis">OASIS</a>
                <div class="menu_block">
                    <a href="forum.php" class="menu">Форум</a>
                    <a href="#" class="menu">Правила сайта</a>
                    <a href="faq.html" class="menu">FAQ</a>
                    <a href="about_us.html" class="menu">О нас</a>
                    <a href="uluch.php" class="menu">Улучшение сайта</a>
                </div>
                <div class="login_panel">
                    <a href="registred.php" class="menu">Регистрация</a>
                </div>
        </div>
    </div>
</header>
<!--Категории-->
<div class="collapse navbar-collapse" id="responsive-menu">
    <ul class="nav navbar-nav">
        <?php
        $categories = get_categories($link);
        ?>
        <?php if(count($categories) === 0): ?>
        <!--<li><a href="#"><i class="plus"></i> Добавить категорию</a></li>-->
        <?php else: ?>
        <?php foreach($categories as $category): ?>
        <a href="/category.php?id=<?=$category["Код"]?>"><?=$category["Категория"]?></a>
        <?php endforeach; ?>
        <?php endif; ?>   
    </ul>
</div>
<!--Посты-->
<div class="forum_section">
    <?php
        $dbUser= 'lera';
        $dbName= 'oasis';
        $dbPass= 'attack';
        $mysqli= new mysqli('localhost', $dbUser, $dbPass, $dbName);
        $query = "set names utf8";
        $mysqli->query($query);
        $query = "select * from products";
        $results = $mysqli->query($query);
        while ($row = $results->fetch_assoc())
        {
            echo '<div class="forum_group">
                    <div class="forum_group_container">
                        <div class="forum_group_img">
                            <div class="forum_text_img">
                                <h4>'.$row["Категория"].'</h4>
                                <p>'.$row["Текст"].'</p>
                            </div>
                            <img src="'.$row["Изображение"].'" alt="" align="" width="200" height="100">
                        </div>
                    </div>
                  </div>';
        }
    ?>
</div>
<a class="back" href="#back">
    <img src="icon/back_1.png" alt="">
</a>
    <!-- Подвал -->
<footer class="footer">
    <h3 class="footer_text_main">Oasis Web</h3>
    <p class="footer_text">oasis.web@gmail.com</p>
    <p class="footer_text">© Oasis Web, 2022.</p>
</footer>-->
    <!-- jаvascript -->
<script src="js/forum.js"></script>

</body>
</html>