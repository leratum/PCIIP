<?php
function get_categories($link) {
    $sql = "SELECT * FROM `kategories`";
    $result = mysqli_query($link, $sql);

    $categories = mysqli_fetch_all($result, 1);

    return $categories;
}

$categories = get_categories($link);