<?php
require_once 'podkl/database.php';
require_once 'podkl/functions.php';
?>
<!doctype html>
<html lang="ru" xmlns="http://www.w3.org/1999/html">
<head>
    <meta charset="UTF-8">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300;400;500;600;700;800&family=Oswald:wght@200;300;400;500;600;700&family=Playfair+Display:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/forum.css">
    <link rel="icon" href="icon/Oasis.png">
    <title>Oasis Web</title>
</head>
<body>
    <!-- Обратная связь -->
    <div class="forum_container">
        <div class="container">
            <div class="menu_header">
                <ul>
                    <li><span class="icon-bar"></span></li>
                    <li><span class="icon-bar"></span></li>
                    <li><span class="icon-bar"></span></li>
                    <li><span class="icon-bar"></span></li>
                
                
                
                
                </ul>
                
            </div>
                        <div class="collapse navbar-collapse" id="responsive-menu">
                            <ul class="nav navbar-nav">
                                <?php
                                $categories = get_categories($link);
                                ?>
                                <?php if(count($categories) === 0): ?>
                               <li><a href="#"><i class="plus"></i> Добавить категорию</a></li>
                                <?php else: ?>
                                <?php foreach($categories as $category): ?>
                                <li><a href="/category.php?id=<?=$category["Код"]?>"><?=$category["Категория"]?></a></li>
                                <?php endforeach; ?>
                                <?php endif; ?>   
                                </ul>
                        </div>