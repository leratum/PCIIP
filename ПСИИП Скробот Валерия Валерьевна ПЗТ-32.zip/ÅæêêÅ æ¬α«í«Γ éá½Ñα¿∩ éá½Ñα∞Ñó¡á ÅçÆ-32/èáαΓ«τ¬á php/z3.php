<?php 

$n = 'Скробот Валерия ';
$i = 5;
while ($i + $n):
    echo $n;
    $i++;
endwhile;

?>