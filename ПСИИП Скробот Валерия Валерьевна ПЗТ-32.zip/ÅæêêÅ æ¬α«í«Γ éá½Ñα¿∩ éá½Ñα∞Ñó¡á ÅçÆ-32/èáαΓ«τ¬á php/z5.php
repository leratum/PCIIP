<?php 

$S1 = 'Я люблю Беларусь';
$S2 = 'Я будущий программист';

echo 'Длина строки S2 ';
echo strlen($S2);

if(stristr($s1, 'Гродно') === false){
    echo '"Гродно" нет в строке s1';
}

echo stristr($s2, 13);
echo strtolower($S2);

?>