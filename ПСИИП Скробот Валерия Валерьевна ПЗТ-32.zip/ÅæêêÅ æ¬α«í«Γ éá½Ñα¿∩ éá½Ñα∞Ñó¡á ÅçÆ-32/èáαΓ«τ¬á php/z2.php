<?php 

$p = '';
$b = '';
$result = $p . ' ' . $b;
$result .= ' ';
echo $result;

?>