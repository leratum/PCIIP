<?php 

$student = array("Иванов"=>"200", "Петров"=>"340", "Сидоров"=>"800");
echo "sum = " .array_sum($student) . "\n"
?>