// Portions Copyright 2019 Jimb Esser (https://github.com/Jimbly/)
// Released under MIT License: https://opensource.org/licenses/MIT

// Dummy shim module that does not exist in worker bundles, to catch bat requires at bundle-time instead of run-time

module.exports = true;
