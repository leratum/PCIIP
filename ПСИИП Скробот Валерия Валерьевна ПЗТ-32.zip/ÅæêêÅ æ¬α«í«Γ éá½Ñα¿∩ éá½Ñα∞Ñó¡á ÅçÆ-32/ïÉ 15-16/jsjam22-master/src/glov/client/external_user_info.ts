export interface ExternalUserInfo {
  external_id: string;
  name?: string;
  profile_picture_url?: string;
}
